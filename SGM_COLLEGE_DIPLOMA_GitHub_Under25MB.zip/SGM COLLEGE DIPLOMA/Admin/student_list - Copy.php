<?php include 'admin_header.php'; 

error_reporting(0);
if($_POST['btnA'])
{

    $sql="update user_register set status='Active' where id='".$_POST['id']."'";
    if(mysqli_query($conn,$sql))
    {

echo "<script>alert('Student Active')</script>";
    }
    else
    {
echo "Record Not Deleted";

    }
}

if($_POST['btnR'])
{

    $sql="update user_register set status='In Active' where id='".$_POST['id']."'";
    if(mysqli_query($conn,$sql))
    {

echo "<script>alert('Student In Active')</script>";
    }
    else
    {
echo "Record Not Updated";

    }
}

?>

<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Department List</h4>
                                <p class="category">Activity</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>ID</th>
                                    	<th>Name</th>
                                    	<th>Address</th>
                                        <th>Contact</th>
                                        <th>Email</th>
                                        <th>Dept</th>
                                        <th>Status</th>
                                        <th>Action</th>

                                    	
                                    </thead>
                                    <tbody>

                                        <?php

                                        $count=1;

                                        

                                        $sql=mysqli_query($conn,"select * from user_register where dept='".$_SESSION['dept']."'");
                                        while ($data=mysqli_fetch_assoc($sql))
                                        { 
                                        echo '<tr>
                                        <form action="student_list.php" method="post">
                                        <input type="hidden" name="id" value="'.$data['id'].'">
                                        	<td>'.$count++.'</td>
                                            <td>'.$data['name'].'</td>
                                            <td>'.$data['address'].'</td>
                                        	<td>'.$data['contact'].'</td>
                                        	<td>'.$data['email'].'</td>
                                            <td>'.$data['dept'].'</td>
                                            <td>'.$data['status'].'</td>
                                            <td><input type="submit" name="btnA" value="Accept" class="btn btn-danger"></td>
                                              <td><input type="submit" name="btnR" value="Reject" class="btn btn-warning"></td>
                                        	</form>
                                        </tr>';
                                    }

                                        ?>
                                        
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>


                    


                </div>
            </div>
        </div>

<?php include 'admin_footer.php'; ?>