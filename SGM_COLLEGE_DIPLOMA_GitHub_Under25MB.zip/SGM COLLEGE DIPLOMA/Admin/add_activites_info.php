<?php include 'admin_header.php';

if(isset($_POST['btn']))
{
//report
 $imgname1=$_FILES['report']['name'];
echo '<br>'; 
$extension1 = pathinfo($imgname1, PATHINFO_EXTENSION);

$randomno1=rand (0,100000); 
$rename1='images'.date('Ymd').$randomno1;

$newname1=$rename1.'.'.$extension1;

$filename1=$_FILES['report']['tmp_name']; 
if(move_uploaded_file($filename1, 'activities/'.$newname1))
{
echo "uploaded";
}
else
{
echo "not uploaded";
}


$filename1='activities/'.$newname1;

//video

 $imgname2=$_FILES['video']['name'];
echo '<br>'; 
$extension2 = pathinfo($imgname2, PATHINFO_EXTENSION);

$randomno2=rand (0,100000); 
$rename2='images'.date('Ymd').$randomno2;

$newname2=$rename2.'.'.$extension2;

$filename2=$_FILES['video']['tmp_name']; 
if(move_uploaded_file($filename2, 'activities/'.$newname2))
{
echo "uploaded";
}
else
{
echo "not uploaded";
}


$filename2='activities/'.$newname2;

//image

 $imgname3=$_FILES['file']['name'];
echo '<br>'; 
$extension3 = pathinfo($imgname3, PATHINFO_EXTENSION);

$randomno3=rand (0,100000); 
$rename3='images'.date('Ymd').$randomno3;

$newname3=$rename3.'.'.$extension3;

$filename3=$_FILES['file']['tmp_name']; 
if(move_uploaded_file($filename3, 'activities/'.$newname3))
{
echo "uploaded";
}
else
{
echo "not uploaded";
}


$filename3='activities/'.$newname3;



    $sql="insert into activites_tbl(title,activity,adate,link,ayear,dept,filer,video,image,descr)values('".$_POST['title']."','".$_POST['aname']."','".$_POST['adate']."','".$_POST['link']."','".$_POST['ayear']."','".$_POST['dname']."','".$filename1."','".$filename2."','".$filename3."','".$_POST['descr']."')";
    if(mysqli_query($conn,$sql))
    {
        echo "<script>alert('Record Added')</script>";
    }
    else
    {
        echo "Not Inserted";
    }
}

 ?>

<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Add Activity</h4>
                            </div>
                            <div class="content">
                                <form action="add_activites_info.php" method="post" enctype="multipart/form-data">
                                    

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Title</label>
                                                <input type="text" class="form-control" name="title" placeholder="Title" onkeypress="javascript:return isString(event)" required="">
                                            </div>
                                        </div>
                                        
                                    </div>
                                     <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Activity</label>
                                                <select class="form-control" name="aname">
                                                    <?php 
                                            $sql=mysqli_query($conn,"select * from activity_tbl");
                                                while($data=mysqli_fetch_assoc($sql))
                                                  {
                                                    echo '<option>'.$data['aname'].'</option>';
                                                  }

                                                ?>
                                                </select>
                                            </div>
                                        </div>
                                         <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Date</label>
                                                <input type="date" class="form-control" placeholder="" name="adate" required="">
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Link</label>
                                                 <input type="url" class="form-control" placeholder="Link" name="link" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Year</label>
                                                 <input type="text" class="form-control" placeholder="Year" maxlength="4" minlength="4" name="ayear"  onkeypress="javascript:return isNumber(event)" required="">
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Department</label>
                                                 <select class="form-control" name="dname">
                                                  <?php 
                                                   if($_SESSION['utype']=="Hod")
                                       {

                                        $sql=mysqli_query($conn,"select * from department_tbl where dname='".$_SESSION['dept']."'");
                                       }
                                       else
                                       {
                                        $sql=mysqli_query($conn,"select * from department_tbl");
                                       }
                                            
                                                while($data=mysqli_fetch_assoc($sql))
                                                  {
                                                    echo '<option>'.$data['dname'].'</option>';
                                                  }

                                                ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>File Report</label>
                                                 <input type="file" class="form-control" name="report" required="">
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Video</label>
                                                 <input type="file" class="form-control" name="video" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Image </label>
                                                 <input type="file" class="form-control" name="file" required=""  height="100">
                                            </div>
                                        </div>
                                        
                                    </div>


                     

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea rows="5" class="form-control" name="descr" placeholder="Here can be your description" ></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" name="btn" class="btn btn-info btn-fill pull-right">Submit</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
        <?php include 'admin_footer.php'; ?>