<?php 
$conn=mysqli_connect("localhost","root","","activity_db");
session_start();
?>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>SGM COLLEGE - Activities Information List</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
  
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />



    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
<script type="text/javascript" src="validation.js"></script>
</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="purple" data-image="assets/img/sidebar-5.jpg">

    

        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="" class="simple-text">
                   <img src="11.png" height="100" width="100"> 
                   <br>SGM COLLEGE
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <!-- <li>
                    <a href="profile.php">
                        <i class="pe-7s-user"></i>
                        <p>User Profile</p>
                    </a>
                </li> -->

                <?php  
                if($_SESSION['utype']=="Principal")
                {
                echo '<li>
                    <a href="add_activity.php">
                        <i class="pe-7s-note2"></i>
                        <p>Activity</p>
                    </a>
                </li>
                <li>
                    <a href="add_department.php">
                        <i class="pe-7s-news-paper"></i>
                        <p>Department</p>
                    </a>
                </li>
                ';

                }
                ?>
                <li>
                    <a href="add_eleraning.php">
                        <i class="pe-7s-science"></i>
                        <p>Lerning</p>
                    </a>
                </li>

                <?php  
                if($_SESSION['utype']=="Hod")
                {
                echo ' <li>
                    <a href="add_activites_info.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>Activities</p>
                    </a>
                </li>
                ';

                }
                ?>





               
                <li>
                    <a href="add_notice.php">
                        <i class="pe-7s-bell"></i>
                        <p>Notice</p>
                    </a>
                </li>
                 <?php  
                if($_SESSION['utype']=="Principal")
                {
                echo '
                 <li>
                    <a href="activity_list.php">
                        <i class="pe-7s-note2"></i>
                        <p>Activity List</p>
                    </a>
                </li>
                <li>
                    <a href="add_department_list.php">
                        <i class="pe-7s-news-paper"></i>
                        <p>Department List</p>
                    </a>
                </li>';
                }
                ?>
                 <li>
                    <a href="">
                        <i class="fa fa-eye" aria-hidden="true"></i>

                        <p>Views</p>
                    </a>
                </li>
                <li>
                    <a href="add_eleraning_list.php">
                        <i class="pe-7s-science"></i>
                        <p>Lerning List</p>
                    </a>
                </li>
                  
                <li>
                    <a href="add_activites_info_list.php">
                        <i class="pe-7s-map-marker"></i>
                        <p>Activities List</p>
                    </a>
                </li>
                <li>
                    <a href="add_notice_list.php">
                        <i class="pe-7s-bell"></i>
                        <p>Notice List</p>
                    </a>
                </li>
                
              
                 <li>
                    <a href="">
                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>

                        <p>Editing</p>
                    </a>
                </li>
                <li>
                    <a href="editactivites.php">
                         <i class="pe-7s-map-marker"></i>
                        <p>Activities Edit</p>
                    </a>
                </li>
            
            </ul>
        </div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"  ><b>User Type -:<span style="color: orange"><?php echo $_SESSION['utype'] ?></span></b></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                      
                      <!--  <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
                                <p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>-->
                      <!--  <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-globe"></i>
                                    <b class="caret hidden-lg hidden-md"></b>
                                    <p class="hidden-lg hidden-md">
                                        5 Notifications
                                        <b class="caret"></b>
                                    </p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>-->
                        <li>
                           <a href="">
                                <i class="fa fa-search"></i>
                                <p class="hidden-lg hidden-md">Search</p>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        
                       <!-- <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <p>
                                        Dropdown
                                        <b class="caret"></b>
                                    </p>

                              </a>-->
                           <!--   <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>-->
                        </li>
                        <li>
                            <a href="http://localhost/SGM%20COLLEGE%20DIPLOMA/">
                                <p>Log out</p>
                            </a>
                        </li>
                        <li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>