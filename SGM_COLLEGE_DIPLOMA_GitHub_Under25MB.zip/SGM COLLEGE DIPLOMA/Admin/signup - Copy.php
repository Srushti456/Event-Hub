<?php $conn=mysqli_connect("localhost","root","","activity_db"); 

if(isset($_POST['btn']))
{
$sql="insert into admin_register(name,address,contact,email,password,user_type,department)values('".$_POST['cname']."','".$_POST['address']."','".$_POST['ccon']."','".$_POST['email']."','".$_POST['pass']."','".$_POST['utype']."','".$_POST['dept']."')";
if(mysqli_query($conn,$sql))
{
  echo "<script>alert('Record Added')</script>";
}
else
{
  echo "Not Added";
}
}       

?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
  <style type="text/css">
    body
    {
      background-color: skyblue;`
    }
    .container
    {
      padding: 20px;
      background-color: white;
      margin-top: 40px;
    }
  </style>
  <script type="text/javascript" src="validation.js"></script>
</head>
<body>
<div class="row">
  <div class="col-sm-4"></div>
  <div class="col-sm-4">
    <div class="container">
      <form action="signup.php" method="post">
  <br>
  <h2>Signup Here...!</h2>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <label>Name</label>
      <input type="text" onkeypress="javascript:return isString(event)" required=""  name="cname" class="form-control" placeholder="Name">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <label>Address</label>
      <input type="text" name="address" class="form-control" placeholder="Address">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <label>Contact</label>
      <input type="text" name="ccon" onkeypress="javascript:return isNumber(event)" required=""  class="form-control" maxlength="10" minlength="10" placeholder="Contact">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-sm-6">
      <label>User Type</label>
      <select class="form-control" name="utype">
        
        <option>Hod</option>
        <option>Principle</option>
      </select>
    </div>
     <div class="col-sm-6">
      <label>Department</label>
      <select class="form-control" name="dept">
        <?php 
$sql=mysqli_query($conn,"select * from department_tbl");
while($data=mysqli_fetch_assoc($sql))
{
        echo '<option>'.$data['dname'].'</option>';
      }

        ?>
      </select>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <label>Email Id</label>
      <input type="email" name="email" class="form-control" placeholder="Email" required="">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <label>Password</label>
      <input type="password" name="pass" class="form-control" placeholder="Password" required="">
    </div>
  </div>
  <br>
   <div class="row">
    <div class="col-sm-12">
      <input type="submit" name="btn" value="Signup" class="btn btn-primary form-control">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <a href="login.php" class="btn btn-danger form-control">Already Have An Account?</a>
    </div>
  </div>
</form>
</div>
  </div>
  <div class="col-sm-4"></div>
  <br>
</div>


</body>
</html>