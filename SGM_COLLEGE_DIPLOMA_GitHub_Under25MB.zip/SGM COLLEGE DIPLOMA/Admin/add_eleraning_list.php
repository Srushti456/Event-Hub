<?php include 'admin_header.php';


error_reporting(0);
if($_POST['btn'])
{

    $sql="delete from elearn_tbl where id='".$_POST['id']."'";
    if(mysqli_query($conn,$sql))
    {

echo "<script>alert('Record Deleted')</script>";
    }
    else
    {
echo "Record Not Deleted";

    }
}

if($_POST['btnupdate'])
{

    $sql="update elearn_tbl set title='".$_POST['title']."',activity='".$_POST['activity']."',link='".$_POST['link']."',dept='".$_POST['dept']."',notes='".$_POST['notes']."',descr='".$_POST['descr']."' where id='".$_POST['id']."'";
    if(mysqli_query($conn,$sql))
    {

echo "<script>alert('Record Update')</script>";
    }
    else
    {
echo "Record Not Updated";

    }
}

 ?>

<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Elearning List</h4>
                                <p class="category">Elearning</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>ID</th>
                                        <th>Title</th>
                                        <th>Activity</th>
                                        <th>Link</th>
                                        <th>Date</th>
                                        <th>Notes</th>
                                        <th>Description</th>
                                         <th>Delete</th>
                                         <th>Update</th>


                                    </thead>
                                    <tbody>
                                         <?php

                                        $count=1;
                                         if($_SESSION['utype']=="Hod")
                                       {

                                         $sql=mysqli_query($conn,"select * from elearn_tbl where dept='".$_SESSION['dept']."'");
                                       }
                                       else
                                       {
                                        $sql=mysqli_query($conn,"select * from elearn_tbl");
                                       }

                                        
                                        while ($data=mysqli_fetch_assoc($sql))
                                        { 
                                        echo '<tr>
                                        <form action="add_eleraning_list.php" method="post">
                                        <input type="hidden" name="id" value="'.$data['id'].'">
                                            <td>'.$count++.'</td>
                                          <td><input type="text" name="title" value="'.$data['title'].'" class="form-control"></td>
                                          <td><input type="text" name="activity" value="'.$data['activity'].'" class="form-control"></td>
                                          <td><input type="text" name="link" value="'.$data['link'].'" class="form-control"></td>
                                          <td><input type="text" name="dept" value="'.$data['dept'].'" class="form-control"></td>
                                          <td><div class="row">
                                                <div class="col-sm-6">
                                                 <input type="text" name="notes" value="'.$data['notes'].'" class="form-control">
                                                </div>
                                                <div class="col-sm-6">
                                                
                                                      <a href="'.$data['notes'].'">View</a>
                                                </div>
                                                </div></td>
                                          <td><input type="text" name="descr" value="'.$data['descr'].'" class="form-control"></td>


                                            
                                                 <td><input type="submit" name="btn" value="Delete" class="btn btn-danger"></td>
                                                   <td><input type="submit" name="btnupdate" value="Update" class="btn btn-warning"></td>
                                            </form>
                                            
                                        </tr>';
                                    }

                                        ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>


                    


                </div>
            </div>
        </div>

<?php include 'admin_footer.php'; ?>