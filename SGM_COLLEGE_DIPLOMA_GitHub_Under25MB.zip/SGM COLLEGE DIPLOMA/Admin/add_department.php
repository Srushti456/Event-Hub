<?php include 'admin_header.php'; 


if(isset($_POST['btn']))
{

    //image

    $imgname3=$_FILES['file']['name'];
    echo '<br>'; 
    $extension3 = pathinfo($imgname3, PATHINFO_EXTENSION);

    $randomno3=rand (0,100000); 
    $rename3='images'.date('Ymd').$randomno3;

    $newname3=$rename3.'.'.$extension3;

    $filename3=$_FILES['file']['tmp_name']; 
    if(move_uploaded_file($filename3, 'department/'.$newname3))
    {
    echo "uploaded";
    }
    else
    {
    echo "not uploaded";
    } 


    $filename3='department/'.$newname3;


    $sql="insert into department_tbl(dname,descr,file)values('".$_POST['dname']."','".$_POST['descr']."','".$filename3."')";
    if(mysqli_query($conn,$sql))
    {
        echo "<script>alert('Record Added')</script>";
    }
    else
    {
        echo "Not Inserted";
    }
}

?>

<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Add Department</h4>
                            </div>
                            <div class="content">
                                <form action="add_department.php" method="post" enctype="multipart/form-data">
                                    

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Department Name</label>
                                                <input type="text" class="form-control" placeholder="Department" onkeypress="javascript:return isString(event)" required="" name="dname" >
                                            </div>
                                        </div>
                                        
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Department Image</label>
                                                <input type="file" class="form-control" placeholder="Image" onkeypress="javascript:return isString(event)" required="" name="file" >
                                            </div>
                                        </div>
                                        
                                    </div>


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea rows="5" class="form-control" placeholder="Here can be your description" name="descr"></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" name="btn" class="btn btn-info btn-fill pull-right">Submit</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
        <?php include 'admin_footer.php'; ?>