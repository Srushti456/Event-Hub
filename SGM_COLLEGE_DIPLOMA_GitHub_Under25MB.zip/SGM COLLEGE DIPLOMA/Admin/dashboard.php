<?php include 'admin_header.php'; 
//activity count
$query = "SELECT count(id) AS id FROM activity_tbl";
$result = mysqli_query($conn, $query);

// Check if query executed successfully
if ($result) {
    // Fetch the total users count
    $row = mysqli_fetch_assoc($result);
    $activity = $row['id'];

    // Free result set
    mysqli_free_result($result);
} else {
    // Handle query error
    $activity = "N/A";
}

//department count
$query = "SELECT count(id) AS id FROM department_tbl";
$result = mysqli_query($conn, $query);

// Check if query executed successfully
if ($result) {
    // Fetch the total users count
    $row = mysqli_fetch_assoc($result);
    $dept = $row['id'];

    // Free result set
    mysqli_free_result($result);
} else {
    // Handle query error
    $dept = "N/A";
}



//notice count
$query = "SELECT count(id) AS id FROM notice_tbl";
$result = mysqli_query($conn, $query);

// Check if query executed successfully
if ($result) {
    // Fetch the total users count
    $row = mysqli_fetch_assoc($result);
    $notice = $row['id'];

    // Free result set
    mysqli_free_result($result);
} else {
    // Handle query error
    $notice = "N/A";
}

//learning
$query = "SELECT count(id) AS id FROM elearn_tbl";
$result = mysqli_query($conn, $query);

// Check if query executed successfully
if ($result) {
    // Fetch the total users count
    $row = mysqli_fetch_assoc($result);
    $learning = $row['id'];

    // Free result set
    mysqli_free_result($result);
} else {
    // Handle query error
    $learning = "N/A";
}
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                  


                
<div class="mcw">
    <div class="container-fluid" style="padding: 20px;">
        <div class="row">
            <div class="col-md-12">
                <!-- Main Content Area -->
                <div class="panel panel-default">
                    <div class="panel-heading">Dashboard</div>
                    <div class="panel-body">
                        <!-- Dashboard Content -->
                        <div class="row">
                            <div class="col-sm-4">
                                <!-- Card or Information Box -->
                                <div class="panel panel-primary">
                                    <div class="panel-heading">Total Activities</div>
                                    <div class="panel-body">
                                         <h3><?php echo $activity; ?></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <!-- Card or Information Box -->
                                <div class="panel panel-primary">
                                    <div class="panel-heading">Total Department</div>
                                    <div class="panel-body">
                                         <h3><?php echo $dept; ?></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <!-- Another Card or Information Box -->
                                <div class="panel panel-primary">
                                    <div class="panel-heading">Total  Notice</div>
                                    <div class="panel-body">
                                        <h3><?php echo $notice; ?></h3>
                                    </div>
                                </div>
                            </div>

                            </div>
                            <div class="row">
                            <div class="col-sm-4">
                                <!-- Card or Information Box -->
                                <div class="panel panel-primary">
                                    <div class="panel-heading">Total Learning</div>
                                    <div class="panel-body">
                                         <h3><?php echo $learning; ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                            
                        
                        </div>
                      
                </div>
            </div>
        </div>
    </div>
</div>

            </div>
        </div>


       
<?php include 'admin_footer.php'; ?>