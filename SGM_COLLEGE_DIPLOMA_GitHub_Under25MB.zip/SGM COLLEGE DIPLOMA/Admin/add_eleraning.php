<?php include 'admin_header.php'; 

if(isset($_POST['btn']))
{

//report
$imgname1=$_FILES['file']['name'];
echo '<br>'; 
$extension1 = pathinfo($imgname1, PATHINFO_EXTENSION);

$randomno1=rand (0,100000); 
$rename1='images'.date('Ymd').$randomno1;

$newname1=$rename1.'.'.$extension1;

$filename1=$_FILES['file']['tmp_name']; 
if(move_uploaded_file($filename1, 'elearn/'.$newname1))
{
echo "uploaded";
}
else
{
echo "not uploaded";
}


$filename1='elearn/'.$newname1;

    $sql="insert into elearn_tbl(title,activity,link,dept,notes,descr)values('".$_POST['title']."','".$_POST['aname']."','".$_POST['link']."','".$_POST['dname']."','".$filename1."','".$_POST['descr']."')";
    if(mysqli_query($conn,$sql))
    {
        echo "<script>alert('Record Added')</script>";
    }
    else
    {
        echo "Not Inserted";
    }
}

?>

<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Add E-learn</h4>
                            </div>
                            <div class="content">
                                <form action="add_eleraning.php" method="post" enctype="multipart/form-data">
                                    

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Title</label>
                                                <input type="text" class="form-control" name="title" onkeypress="javascript:return isString(event)" required="" placeholder="Title" >
                                            </div>
                                        </div>
                                        
                                    </div>
                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Activity</label>
                                                <select class="form-control" name="aname">
                                            <?php 
                                            $sql=mysqli_query($conn,"select * from activity_tbl");
                                                while($data=mysqli_fetch_assoc($sql))
                                                  {
                                                    echo '<option>'.$data['aname'].'</option>';
                                                  }

                                                ?>
                                                </select>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Link</label>
                                                 <input type="url" class="form-control" name="link" placeholder="Link" required="">
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Department</label>
                                                 <select class="form-control" name="dname">
                                                   <?php 

                                                   if($_SESSION['utype']=="Hod")
                                       {

                                        $sql=mysqli_query($conn,"select * from department_tbl where dname='".$_SESSION['dept']."'");
                                       }
                                       else
                                       {
                                        $sql=mysqli_query($conn,"select * from department_tbl");
                                       }
                                           
                                                while($data=mysqli_fetch_assoc($sql))
                                                  {
                                                    echo '<option>'.$data['dname'].'</option>';
                                                  }

                                                ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Notes</label>
                                                 <input type="file" class="form-control" name="file" required="">
                                            </div>
                                        </div>
                                        
                                    </div>


 

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea rows="5" class="form-control" placeholder="Here can be your description" name="descr"></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" name="btn" class="btn btn-info btn-fill pull-right">Submit</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
        <?php include 'admin_footer.php'; ?>