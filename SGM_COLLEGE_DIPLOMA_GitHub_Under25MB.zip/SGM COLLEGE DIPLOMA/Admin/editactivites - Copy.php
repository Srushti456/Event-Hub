<?php  
include 'admin_header.php';
error_reporting(0);
if($_POST['btn'])
{

    $sql="delete from activites_tbl where id='".$_POST['id']."'";
    if(mysqli_query($conn,$sql))
    {

echo "<script>alert('Record Deleted')</script>";
    }
    else
    {
echo "Record Not Deleted";

    }
}
if($_POST['btnupdate'])
{

    $sql="update activites_tbl set title='".$_POST['title']."',activity='".$_POST['activity']."',adate='".$_POST['adate']."',ayear='".$_POST['ayear']."',dept='".$_POST['dept']."',filer='".$_POST['filer']."',video='".$_POST['video']."',image='".$_POST['image']."',dept='".$_POST['dept']."' where id='".$_POST['id']."'";
    if(mysqli_query($conn,$sql))
    {

echo "<script>alert('Record Update')</script>";
    }
    else
    {
echo "Record Not Updated";

    }
}

?>
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">
<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Activities Information List</h4>
                                <p class="category">Activities Information</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                                


                                <table id="example" class="display table table-hover table-striped" style="width:100%">
    <thead>
        <tr>
            <th>ID</th>
                                        <th>Title</th>
                                        <th>Activity</th>
                                        <th>Date</th>
                                        <th>Link</th>
                                        <th>Year</th>
                                        <th>Department</th>
                                        <th>File</th>
                                        <th>Video</th>
                                        <th>Image</th>
                                        <th>Description</th>
                                         <th>Delete</th>
                                         <th>Update</th>
        </tr>
    </thead>
    <tbody>
        <?php

                                        $count=1;

                                        $sql="";


                                       if($_SESSION['utype']=="Hod")
                                       {

                                         $sql=mysqli_query($conn,"select * from activites_tbl where dept='".$_SESSION['dept']."'");
                                       }
                                       else
                                       {
                                        $sql=mysqli_query($conn,"select * from activites_tbl");
                                       }

                                        while ($data=mysqli_fetch_assoc($sql))
                                        { 
                                        echo '<tr>
                                        <form action="editactivites.php" method="post">
                                        <input type="hidden" name="id" value="'.$data['id'].'">
                                            <td>'.$count++.'</td>

                                           <td><input type="text" name="title" value="'.$data['title'].'" class="form-control"></td>
                                           <td><input type="text" name="activity" value="'.$data['activity'].'" class="form-control"></td>
                                           <td><input type="text" name="adate" value="'.$data['adate'].'" class="form-control"></td>
                                           <td><input type="text" name="link" value="'.$data['link'].'" class="form-control"></td>
                                           <td><input type="text" name="ayear" value="'.$data['ayear'].'" class="form-control"></td>
                                           <td><input type="text" name="dept" value="'.$data['dept'].'" class="form-control"></td>
                                           <td><div class="row">
                                                <div class="col-sm-6">
                                                 <input type="text" name="filer" value="'.$data['filer'].'" class="form-control">
                                                </div>
                                                <div class="col-sm-6">
                                                
                                                      <a href="'.$data['filer'].'">View</a>
                                                </div>
                                                </div></td>
                                           <td><div class="row">
                                                <div class="col-sm-6">
                                                 <input type="text" name="video" value="'.$data['video'].'" class="form-control">
                                                </div>
                                                <div class="col-sm-6">
                                                
                                                      <a href="'.$data['video'].'">View</a>
                                                </div>
                                                </div></td>
                                           <td><div class="row">
                                                <div class="col-sm-6">
                                                 <input type="text" name="image" value="'.$data['image'].'" class="form-control">
                                                </div>
                                                <div class="col-sm-6">
                                                
                                                      <a href="'.$data['image'].'">View</a>
                                                </div>
                                                </div></td>
                                           <td><input type="text" name="descr" value="'.$data['descr'].'" class="form-control"></td>

                                           
                                             <td><input type="submit" name="btn" value="Delete" class="btn btn-danger"></td>
                                               <td><input type="submit" name="btnupdate" value="Update" class="btn btn-warning"></td>
                                            </form>
                                            
                                        </tr>';
                                    }

                                        ?>
        <!-- more rows -->
    </tbody>
</table>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.70/vfs_fonts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>

<!-- <script>
$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5',
            'print'
        ]
    });
});
</script> -->



                            </div>
                        </div>
                    </div>

 
        

                    


                </div>
            </div>
        </div>
<?php include 'admin_footer.php';?>