<?php $conn=mysqli_connect("localhost","root","","activity_db"); 
session_start();
if(isset($_POST['btn']))
{
    $sql=mysqli_query($conn,"select * from admin_register where email='".$_POST['user']."' and password='".$_POST['password']."' and user_type='".$_POST['utype']."'");
    $data=mysqli_fetch_assoc($sql);
    if($data['email']==$_POST['user'] && $data['password']==$_POST['password'] && $data['user_type']==$_POST['utype'])
    {
        $_SESSION['dept']=$data['department'];
        $_SESSION['utype']=$data['user_type'];
        header('location:dashboard.php');
    }
    else
    {
        echo "<script>alert('Login Fail')</script>";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
  <style type="text/css">
    body
    {
      background-color: skyblue;
    }
    .container
    {
      padding: 20px;
      background-color: white;
      margin-top: 100px;
    }
  </style>
</head>
<body>
<div class="row">
  <div class="col-sm-4"></div>
  <div class="col-sm-4">
    <div class="container">
      <form action="login.php" method="post">
  <br>
  <h2>Login Here...!</h2>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <label>User Type</label>
      <select class="form-control" name="utype">
        <option>Select</option>
        <option>Hod</option>
        <option>Principal</option>
      </select>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <label>Email Id</label>
      <input type="email" name="user" class="form-control" placeholder="Email">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <label>Password</label>
      <input type="password" name="password" class="form-control" placeholder="Password">
    </div>
  </div>
  <br>
   <div class="row">
    <div class="col-sm-12">
      <input type="submit" name="btn" value="Login" class="btn btn-primary form-control">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-sm-12">
      <a href="signup.php"  class="btn btn-danger form-control">Create An New Account</a>
    </div>
  </div>
  </form>
</div>
  </div>
  <div class="col-sm-4"></div>
</div>


</body>
</html>