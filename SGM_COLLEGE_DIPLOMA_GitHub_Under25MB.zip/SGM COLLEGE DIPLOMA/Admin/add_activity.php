<?php include 'admin_header.php'; 

if(isset($_POST['btn']))
{
    $sql="insert into activity_tbl(aname,descr)values('".$_POST['aname']."','".$_POST['descr']."')";
    if(mysqli_query($conn,$sql))
    {
        echo "<script>alert('Record Added')</script>";
    }
    else
    {
        echo "Not Inserted";
    }
}


?>
<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Add Activity</h4>
                            </div>
                            <div class="content">
                                <form action="add_activity.php" method="post">
                                    

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Activity Name</label>
                                                <input type="text" class="form-control" name="aname" onkeypress="javascript:return isString(event)" required="" placeholder="Activity Name" >
                                            </div>
                                        </div>
                                        
                                    </div>

 

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea rows="5" class="form-control" placeholder="Here can be your description" name="descr"></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" name="btn" class="btn btn-info btn-fill pull-right">Submit</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    

                </div>
            </div>
        </div>
        <?php include 'admin_footer.php'; ?>