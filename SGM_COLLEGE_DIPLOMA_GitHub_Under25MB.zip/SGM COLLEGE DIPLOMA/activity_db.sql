-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2024 at 08:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `activity_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `activites_tbl`
--

CREATE TABLE `activites_tbl` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `activity` varchar(50) NOT NULL,
  `adate` varchar(50) NOT NULL,
  `link` varchar(500) NOT NULL,
  `ayear` varchar(50) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `filer` varchar(500) NOT NULL,
  `video` varchar(500) NOT NULL,
  `image` varchar(500) NOT NULL,
  `descr` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activites_tbl`
--

INSERT INTO `activites_tbl` (`id`, `title`, `activity`, `adate`, `link`, `ayear`, `dept`, `filer`, `video`, `image`, `descr`) VALUES
(4, 'Abc', 'A', '2024-03-03', 'http://www.a.com', '2024', 'Computer science', 'activities/images2024030395742.pdf', 'activities/images2024030349822.mp4', 'activities/images2024030344191.jpeg', 'abcd'),
(6, 'Dhulivandan', 'Cultural Event', '2024-03-25', 'http://www.tutlane.com', '2024', 'Mechanical Engineering', 'activities/images2024032566605.pdf', 'activities/images2024032565700.pdf', 'activities/images202403253631.jpg', 'Celebrated Dhulivandan'),
(7, 'Dhulivandan', 'Cultural Event', '2023-03-22', 'http://www.tutlane.com', '2024', 'Computeer Engineering', 'activities/images202403257237.docx', 'activities/images2024032532497.mp4', 'activities/images2024032549017.png', 'Cultural'),
(8, 'Celebrate Rangpanchami', 'Cultural Event', '2023-03-25', 'http://www.tutlane.com', '2023', 'Civil Engineering', 'activities/images2024032527427.pdf', 'activities/images202403252828.mp4', 'activities/images202403251348.jpg', 'Rangpanchami'),
(9, 'Inspirational speech', 'Guest lecture', '2024-03-25', 'http://www.tutlane.com', '2024', 'Electrical Engineering', 'activities/images2024032523874.pdf', 'activities/images2024032530175.mp4', 'activities/images2024032590621.jpg', 'Speech'),
(10, 'Inspirational speech', 'Cultural Event', '2024-03-25', 'http://www.tutlane.com', '2024', '', 'activities/images2024032581284.pdf', 'activities/images2024032543235.mp4', 'activities/images2024032539940.jpg', 'speech'),
(12, 'Dance performance', 'Cultural Event', '2024-02-21', 'https://api.minio.storage.edigicloud.com/sgm-web/SGM/galleries/269/875.jpeg', '2023', 'Computeer Engineering', 'activities/images2024032586417.docx', 'activities/images2024032532136.html', 'activities/images2024032595098.jpg', 'Dance performance');

-- --------------------------------------------------------

--
-- Table structure for table `activity_tbl`
--

CREATE TABLE `activity_tbl` (
  `id` int(11) NOT NULL,
  `aname` varchar(50) NOT NULL,
  `descr` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_tbl`
--

INSERT INTO `activity_tbl` (`id`, `aname`, `descr`) VALUES
(3, 'Cultural  Event', 'cultural event'),
(4, 'Guest lecture', 'Guest lecture'),
(5, 'Technical Event', 'Technical event'),
(6, 'Sports ', 'Sports'),
(7, 'Anuttara Event', 'Anuttara event'),
(8, 'Social Activity', 'Social Activity');

-- --------------------------------------------------------

--
-- Table structure for table `admin_register`
--

CREATE TABLE `admin_register` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_register`
--

INSERT INTO `admin_register` (`id`, `name`, `address`, `contact`, `email`, `password`, `user_type`, `department`) VALUES
(1, 'Sumit Patil', 'Kedar complex near MR highschool gadhinglaj', '9865321245', 'amit@gmail.com', '123456', '', ''),
(2, 'Amit', 'Kedar complex near MR highschool gadhinglaj', '9865321245', 'amit@gmail.com', '123456', 'Hod', 'Computer science'),
(3, 'Sumit', 'Gad', '9865321245', 'amit@gmail.com', '123456', 'Principle', 'Computer science'),
(4, 'Rohoni', 'Gadhinglaj', '9836654545', 'sgm@gmail.com', '123456', 'Principal', 'Computer science'),
(5, 'G K Birangaddi', 'Gadhinglaj', '9836654545', 'co123@gmail.com', 'co123@', 'Hod', 'Computeer Engineering'),
(6, 'M P Patil', 'Nool', '9402456455', 'ee123@gmail.com', 'ee123@', 'Hod', 'Electrical Engineering'),
(7, 'A B Kori', 'Gadhinglaj', '7277263455', 'me@gmail.com', 'me123@', 'Hod', 'Mechanical Engineering'),
(8, 'A C Kamble', 'Khandal', '9420466266', 'ce123@gmail.com', 'ce123@', 'Hod', 'Civil Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `department_tbl`
--

CREATE TABLE `department_tbl` (
  `id` int(11) NOT NULL,
  `dname` varchar(50) NOT NULL,
  `descr` varchar(500) NOT NULL,
  `file` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department_tbl`
--

INSERT INTO `department_tbl` (`id`, `dname`, `descr`, `file`) VALUES
(4, 'Computeer Engineering', 'Computer Engineering', 'department/images2024032375021.jpg'),
(5, 'Mechanical Engineering', 'Mechanical Engineering', 'department/images2024032318960.jpg'),
(6, 'Electrical Engineering', 'Electrical Engineering', 'department/images2024032512305.jpg'),
(7, 'Civil Engineering', 'Civil Engineering', 'department/images2024032537238.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `elearn_tbl`
--

CREATE TABLE `elearn_tbl` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `activity` varchar(50) NOT NULL,
  `link` varchar(500) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `notes` varchar(500) NOT NULL,
  `descr` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `elearn_tbl`
--

INSERT INTO `elearn_tbl` (`id`, `title`, `activity`, `link`, `dept`, `notes`, `descr`) VALUES
(1, 'guest lecture videos', 'Guest Lecture', 'http://www.a.com', 'A', 'automatic_billing_smart_trolley.sql', 'a'),
(2, 'Abc', 'Cultural Event', 'http://www.a.com', 'Computer science', 'elearn/images2024030352138.sql', 'abcd'),
(3, 'Dhulivandan', 'Cultural Event', 'http://www.tutlane.com', 'Electrical Engineering', 'elearn/images2024032596530.docx', 'Cultural'),
(4, 'guest lecture videos', 'Guest lecture', 'https://www.bing.com/videos/riverview/relatedvideo?q=vishwas+nangare+patil+speech+in+college&mid=313E47A8FE80520E5680313E47A8FE80520E5680&FORM=VIRE', 'Computeer Engineering', 'elearn/images2024032553735.docx', 'Guest lecture');

-- --------------------------------------------------------

--
-- Table structure for table `notice_tbl`
--

CREATE TABLE `notice_tbl` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `activity` varchar(50) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `ndate` varchar(50) NOT NULL,
  `file` varchar(500) NOT NULL,
  `descr` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notice_tbl`
--

INSERT INTO `notice_tbl` (`id`, `title`, `activity`, `dept`, `ndate`, `file`, `descr`) VALUES
(5, 'Celebrate Rangpanchami', 'Cultural Event', 'Computeer Engineering', '2024-03-25', 'notice/images2024032532819.png', 'Organize activity for Rangpanchami'),
(6, 'Arrange guest lecture', 'Guest lecture', 'Computeer Engineering', '2024-03-25', 'notice/images202403252185.png', 'Guest lecture'),
(7, 'Dance performance', 'Cultural Event', 'Computeer Engineering', '2024-03-25', 'notice/images20240325145.pdf', 'Dance'),
(8, 'Inspirational speech', 'Cultural Event', 'Computeer Engineering', '2024-03-25', 'notice/images2024032511833.pdf', 'sds'),
(9, 'Inspirational speech', 'Cultural Event', 'Computeer Engineering', '2024-03-25', 'notice/images2024032550278.pdf', 'dsfd');

-- --------------------------------------------------------

--
-- Table structure for table `user_register`
--

CREATE TABLE `user_register` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contact` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_register`
--

INSERT INTO `user_register` (`id`, `name`, `address`, `contact`, `email`, `password`, `dept`, `status`) VALUES
(1, 'Sumit Patil', 'Kedar complex near MR highschool gadhinglaj', 9865321245, 'amit@gmail.com', '12345', '', ''),
(2, 'Sumit Patil', 'Kedar complex near MR highschool gadhinglaj', 9865321245, 'amit@gmail.com', '12345', '', ''),
(3, 'Sumit Patil', 'Kedar complex near MR highschool gadhinglaj', 9865321245, 'amit@gmail.com', '123456', 'Computer science', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activites_tbl`
--
ALTER TABLE `activites_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity_tbl`
--
ALTER TABLE `activity_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_register`
--
ALTER TABLE `admin_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department_tbl`
--
ALTER TABLE `department_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `elearn_tbl`
--
ALTER TABLE `elearn_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice_tbl`
--
ALTER TABLE `notice_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_register`
--
ALTER TABLE `user_register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activites_tbl`
--
ALTER TABLE `activites_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `activity_tbl`
--
ALTER TABLE `activity_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `admin_register`
--
ALTER TABLE `admin_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `department_tbl`
--
ALTER TABLE `department_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `elearn_tbl`
--
ALTER TABLE `elearn_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notice_tbl`
--
ALTER TABLE `notice_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_register`
--
ALTER TABLE `user_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
