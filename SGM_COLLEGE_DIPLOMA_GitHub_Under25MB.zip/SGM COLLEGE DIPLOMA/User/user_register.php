<?php $conn=mysqli_connect("localhost","root","","activity_db"); 

if(isset($_POST['btn']))
{

$sql="insert into user_register(name,address,contact,email,password,dept)values('".$_POST['cname']."','".$_POST['address']."','".$_POST['ccon']."','".$_POST['email']."','".$_POST['pass']."','".$_POST['dept']."')";
if(mysqli_query($conn,$sql))
{
  echo "<script>alert('Record Added')</script>";
}
else
{
  echo "Not Added";
}
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>User Login</title>
         <link rel="stylesheet" href="bootstrap.min.css">
         <script src="validation.js"></script>
          <style>
            body
            {
                background-color: whitesmoke;
            }
            
           .container
           {
               background-color: white;
               margin-top: 20px;
               padding: 30px;
               margin-bottom: 20px;
           }
           
           h3
           {
               text-align: center;
           }

        </style>
    </head>
    <body>
       
       <form action="user_register.php" method="post">
        <div class="row">
            <div class="col-sm-3"></div>
             <div class="col-sm-6">
            <div class="container-fluid">
        <div class="container">
            <h3>User Register</h3>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Name</label>
            <input type="text" class="form-control"  name="cname" placeholder="Name" onkeypress="javascript:return isString(event)" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Address</label>
            <input type="text" class="form-control" name="address" placeholder="Address" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Contact no</label>
            <input type="text" class="form-control" name="ccon" placeholder="Contact no" maxlength="10" minlength="10" onkeypress="javascript:return isNumber(event)" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Email id</label>
            <input type="email" class="form-control" name="email" placeholder="Email id" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
        <br>
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <label>Department</label>
      <select class="form-control" name="dept">
        <?php 
$sql=mysqli_query($conn,"select * from department_tbl");
while($data=mysqli_fetch_assoc($sql))
{
        echo '<option>'.$data['dname'].'</option>';
      }

        ?>
      </select>
            </div>
            <div class="col-sm-2"></div>
        </div>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Password</label>
            <input type="password" class="form-control" name="pass" placeholder="Password" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
            <br>
        
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            
            <input type="submit" class="btn btn-info btn-block col-12" name="btn" value="Signin">
            
        </div>
        <div class="col-sm-2"></div>
        </div>
                <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            
            <a href="user_login.php" class="btn btn-danger btn-block col-12" >Have An Account?</a>
            
        </div>
        <div class="col-sm-2"></div>
        </div>
        </div>
            </div>
            <div class="col-sm-3"></div>
            </div>
        </div>
        </form>
    </body>
</html>