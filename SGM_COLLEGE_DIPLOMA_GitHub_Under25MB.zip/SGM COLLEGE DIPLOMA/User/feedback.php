<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <link rel="stylesheet" href="bootstrap.min.css">
         <script src="validation.js"></script>
          <style>
            body
            {
                background-color: whitesmoke;
            }
            
           .container
           {
               background-color: white;
               margin-top: 20px;
               padding: 30px;
               margin-bottom: 20px;
           }
           
           h3
           {
               text-align: center;
           }

        </style>
    </head>
    <body>
        <form action="feedback" method="post">
        <div class="row">
            <div class="col-sm-3"></div>
             <div class="col-sm-6">
            <div class="container-fluid">
        <div class="container">
            <h3>Feedback</h3>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Name</label>
            <input type="text"  class="form-control" name="cname" placeholder="Name" onkeypress="javascript:return isString(event)" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Address</label>
            <input type="text" class="form-control" name="address" placeholder="Address" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Email</label>
            <input type="email" class="form-control" name="email" placeholder="Email" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Feedback</label>
            <input type="text" class="form-control" name="feedback" placeholder="Feedback" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
            <br>
       
            
        
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            
            <input type="submit" class="btn btn-info btn-block col-12" name="btn" value="Submit">
            
        </div>
        <div class="col-sm-2"></div>
        </div>
                <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            
            <input type="submit" class="btn btn-danger btn-block col-12" name="btn" value="Cancel">
            
        </div>
        <div class="col-sm-2"></div>
        </div>
        </div>
            </div>
            <div class="col-sm-3"></div>
            </div>
        </div>
        </form>
    </body>
</html>