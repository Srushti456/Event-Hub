
<?php $conn=mysqli_connect("localhost","root","","activity_db"); 
error_reporting(0);
if(isset($_POST['btn']))
{
    $sql=mysqli_query($conn,"select * from user_register where email='".$_POST['user']."' and password='".$_POST['password']."' and status='Active'");
    $data=mysqli_fetch_assoc($sql);
    if($data['email']==$_POST['user'] && $data['password']==$_POST['password'] && $data['status']=='Active')
    {
        $_SESSION['dept']=$data['dept'];
        header('location:years.php');
    }
    else
    {
        echo "<script>alert('Incorrect Username & Password & You Are Not Active')</script>";
    }
}

?><!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>PharmEasy</title>
        <link rel="stylesheet" href="bootstrap.min.css">
        <style>
            body
            {
                background-color: whitesmoke;
            }
            
           .container
           {
               background-color: white;
               margin-top: 20px;
               padding: 30px;
               margin-bottom: 20px;
           }
           
           h3
           {
               text-align: center;
           }

        </style>
    </head>
    <body>
       
        <form action="user_login.php" method="post">
        <div class="row">
            <div class="col-sm-3"></div>
             <div class="col-sm-6">
                 <div class="container-fluid">
        <div class="container">
            <h3>User Login</h3>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Username</label>
            <input type="text" class="form-control" name="user" placeholder="Username" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
            <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <label>Password</label>
            <input type="password" class="form-control" name="password" placeholder="Password" required="">
        </div>
        <div class="col-sm-2"></div>
        </div>
        <br>
        
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            
            <input type="submit" class="btn btn-info btn-block col-12" name="btn" value="Login">
            
        </div>
        <div class="col-sm-2"></div>
        </div>
                <br>
        <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            
            <a href="user_register.php" class="btn btn-danger btn-block col-12">Create a new account</a>
            
            
        </div>
        <div class="col-sm-2"></div>
        </div>
        </div>
                 </div>
            <div class="col-sm-3"></div>
            </div>
        </div>
        </form>
    </body>
</html>