
<?php include 'user_header.php'; 

?>
    <!--//header-->

    <!-- inner banner -->
    <div class="inner-banner">
        <div class="w3l-breadcrumb">
            <div class="container">
                <h4 class="inner-text-title font-weight-bold text-white mb-sm-3 mb-2">Courses</h4>
                <ul class="breadcrumbs-custom-path">
                    <li><a href="index.html">Home</a></li>
                    <li class="active"><span class="fa fa-chevron-right mx-2" aria-hidden="true"></span>E-Learn
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- //inner banner -->

    <!-- courses section -->
    <div class="w3l-grids-block-5 w3l-grids-block-6 py-5">
        <div class="container py-md-5 py-4">
            <div class="title-heading-w3 text-center mx-auto mb-5 pb-sm-4">
                <h3 class="title-main">Our <span>E-Learn</span></h3>
            </div>
            <div class="row">
<?php 
error_reporting(0);
$sql="";

if($_SESSION['dnames'])
{

$sql=mysqli_query($conn,"select * from elearn_tbl where dept='".$_SESSION['dnames']."'");
}
else
{
    
    $sql=mysqli_query($conn,"select * from elearn_tbl ");
}




while($data=mysqli_fetch_assoc($sql))
{
                echo '<div class="col-lg-4 col-md-6">
                    <div class="blog-card-single">
                        <div class="grids5-info position-relative">
                            <img src="assets/images/c1.jpg" alt="" class="img-fluid" />
                            
                           
                        </div>
                        <div class="content-main-top">
                            <div class="content-top mb-4 mt-3">
                                <ul class="list-unstyled d-flex align-items-center justify-content-between">
                                    <li> <i class="fa fa-signal" aria-hidden="true"></i> '.$data['title'].'</li>
                                    <li>  </li>
                                </ul>
                            </div>
                            <h4><a href="'.$data['link'].'">Click Here</a></h4>
                             <h4><a href="../Admin/'.$data['notes'].'">Download Report</a></h4>
                             
                              <p>'.$data['activity'].'</p>
                               <p>'.$data['dept'].'</p>
                            <p>'.$data['descr'].'</p>
                            
                        </div>
                    </div>
                </div>';
            }
                ?>
                
                
                
                
                
            </div>
            <!-- pagination -->
            
            <!-- //pagination -->
        </div>
    </div>
    <!-- //courses section -->

    <!-- footer -->
    <?php include 'user_footer.php'; ?>