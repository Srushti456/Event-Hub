<?php include 'user_header.php'; ?>
    <!--//header-->

    <!-- inner banner -->
    <div class="inner-banner">
        <section class="w3l-breadcrumb">
            <div class="container">
                <h4 class="inner-text-title font-weight-bold text-white mb-sm-3 mb-2">Contact Us</h4>
                <ul class="breadcrumbs-custom-path">
                    <li><a href="index.html">Home</a></li>
                    <li class="active"><span class="fa fa-chevron-right mx-2" aria-hidden="true"></span> Contact Us</li>
                </ul>
            </div>
        </section>
    </div>
    <!-- //inner banner -->

    <!-- contact page -->
    <section class="w3l-contact py-5" id="contact">
        <div class="container py-md-5 py-4 mb-5">
            <div class="mx-auto" style="max-width:1000px">
                <div class="row contact-block">
                    <div class="col-md-5 contact-left">
                        <h3 class="font-weight-bold mb-md-5 mb-4">Get in touch with us</h3>
                        <div class="cont-details">
                            <div class="d-flex contact-grid">
                                <div class="cont-left text-center mr-3">
                                    <span class="fa fa-globe"></span>
                                </div>
                                <div class="cont-right">
                                    <h6>College Address</h6>
                                    <p>Gadhinglaj,Gadhinglaj

Taluka:Gadhinglaj,Dist:Kolhapur

(Maharashtra) - 416503

</p>
                                </div>
                            </div>
                            <div class="d-flex contact-grid mt-4 pt-lg-2">
                                <div class="cont-left text-center mr-3">
                                    <span class="fa fa-phone"></span>
                                </div>
                                <div class="cont-right">
                                    <h6>Call Us</h6>
                                    <p><a href="tel:+1(21) 234 4567">+91 9421038723</a></p>
                                </div>
                            </div>
                            <div class="d-flex contact-grid mt-4 pt-lg-2">
                                <div class="cont-left text-center mr-3">
                                    <span class="fa fa-envelope-open"></span>
                                </div>
                                <div class="cont-right">
                                    <h6>Email Us</h6>
                                    <p><a href="mailto:example@mail.com" class="mail">sanjaysawant2010@gmail.com</a></p>
                                </div>
                            </div>
                            <div class="d-flex contact-grid mt-4 pt-lg-2">
                                <div class="cont-left text-center mr-3">
                                    <span class="fa fa-headphones"></span>
                                </div>
                                <div class="cont-right">
                                    <h6>Customer Support</h6>
                                    <p><a href="mailto:info@support.com" class="mail">sanjaysawant2010@gmail.com</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7 mt-md-0 mt-4">
                        <div class="map-iframe">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15328.79218703133!2d74.3752749!3d16.1587341!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc08fafbdbc15fb%3A0x2baa1b4f69d1fb02!2sSant%20Gajanan%20Maharaj%20College%20of%20Engineering%2C%20Mahagaon!5e0!3m2!1sen!2sin!4v1709121756263!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
                <!-- contact form -->
                <div class="contact-form-sec pt-5 mt-md-5">
                    <div class="title-heading-w3 text-center mx-auto mb-5 pb-sm-4">
                        <h3 class="title-main">We will Answer all your <span>Questions</span></h3>
                    </div>
                    <div class="row contact-block align-items-center">
                        <div class="col-md-5 contact-left">
                            <img src="assets/images/contact.jpg" alt="" class="img-fluid img-responsive">
                        </div>
                        <div class="col-md-7 contact-right mt-md-0 mt-4 pl-lg-4">
                            <form action="https://sendmail.w3layouts.com/submitForm" method="post" class="signin-form">
                                <div class="input-grids">
                                    <input type="text" name="w3lName" id="w3lName" placeholder="Your Name*"
                                        class="contact-input" required="" />
                                    <input type="email" name="w3lSender" id="w3lSender" placeholder="Your Email*"
                                        class="contact-input" required="" />
                                    <input type="text" name="w3lSubect" id="w3lSubect" placeholder="Subject*"
                                        class="contact-input" required="" />
                                </div>
                                <div class="form-input">
                                    <textarea name="w3lMessage" id="w3lMessage" placeholder="Type your message here*"
                                        required=""></textarea>
                                </div>
                                <button class="btn btn-style btn-style-secondary mt-sm-3">Send Message</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- //contact form -->
            </div>
        </div>
    </section>
    <!-- //contact page -->

    <!-- footer -->
    <?php include 'user_footer.php'; ?>