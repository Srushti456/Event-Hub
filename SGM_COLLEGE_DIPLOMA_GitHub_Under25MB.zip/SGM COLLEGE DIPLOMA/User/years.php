
<?php include 'user_header.php';

if(isset($_POST['year']))
{
    $_SESSION['years']=$_POST['year'];
    echo "<script>
    window.location = 'department.php';
</script>";
}

 ?>
    <!--//header-->

    <!-- inner banner -->
    <div class="inner-banner">
        <div class="w3l-breadcrumb">
            <div class="container">
                <h4 class="inner-text-title font-weight-bold text-white mb-sm-3 mb-2">Years View</h4>
                <ul class="breadcrumbs-custom-path">
                    <li><a href="index.html">Home</a></li>
                    <li class="active"><span class="fa fa-chevron-right mx-2" aria-hidden="true"></span>Years View
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- //inner banner -->

    <!-- courses section -->
    <div class="w3l-grids-block-5 w3l-grids-block-6 py-5">
        <div class="container py-md-5 py-4">
            <div class="title-heading-w3 text-center mx-auto mb-5 pb-sm-4">
                <h3 class="title-main">Our <span>Activites</span></h3>
            </div>
            <div class="row">
<?php 

$sql=mysqli_query($conn,"select DISTINCT ayear from activites_tbl");
while($data=mysqli_fetch_assoc($sql))
{
                echo '<div class="col-lg-4 col-md-6">
                <form action="years.php" method="post">
                    <div class="blog-card-single">
                        <div class="grids5-info position-relative">
                         
                           
                        </div>
                        <div class="content-main-top" style="background-color:skyblue">
                            <div class="content-top mb-4 mt-3">
                                <ul class="list-unstyled d-flex align-items-center justify-content-between">
                                    <li> <i class="fa fa-signal" aria-hidden="true"></i> <button type="submit" class="btn btn-primary" name="year" value="'.$data['ayear'].'">'.$data['ayear'].'</button></li>
                                   
                                </ul>
                            </div>
                           
                            
                        </div>
                    </div>
                    </form>
                </div>';
            }
                ?>
                
                
                
                
                
            </div>
            <!-- pagination -->
            
            <!-- //pagination -->
        </div>
    </div>
    <!-- //courses section -->

    <!-- footer -->
    <?php include 'user_footer.php'; ?>