<?php include 'user_header.php'; ?>
    <!--//header-->

    <!-- inner banner -->
    <div class="inner-banner">
        <section class="w3l-breadcrumb">
            <div class="container">
                <h4 class="inner-text-title font-weight-bold text-white mb-sm-3 mb-2">About Us</h4>
                <ul class="breadcrumbs-custom-path">
                    <li><a href="index.html">Home</a></li>
                    <li class="active"><span class="fa fa-chevron-right mx-2" aria-hidden="true"></span>About Us</li>
                </ul>
            </div>
        </section>
    </div>
    <!-- //inner banner -->

    <!-- about section -->
    <section class="video-section py-5">
        <div class="container py-md-5 py-4">
            <div class="row">
                <div class="col-lg-6 about-right-faq align-self pr-lg-5">
                    <h3 class="title-big">Our Mission is to Provide a World‑class Education</h3>
                    <p class="mt-3">The Sant Gajanan Maharaj Group Of Education is one of the leading Education hub at Gadhinglaj comes under Shivaji University, Kolhapur. </p>
                </div>
                <div class="col-lg-6 left-wthree-img-video text-righ pr-lg-5 mt-lg-0 mt-5">
                    <div class="position-relative text-center">
                        <img src="assets/images/clg1.jpg" alt="" class="img-fluid">
                        <a href="#small-dialog" class="popup-with-zoom-anim play-view text-center position-absolute">
                           <!-- <span class="video-play-icon">
                                <span class="fa fa-play"></span>
                            </span>-->
                        </a>

                        <!-- dialog itself, mfp-hide class is required to make dialog hidden -->
                        <div id="small-dialog" class="zoom-anim-dialog mfp-hide">
                            <iframe src="https://player.vimeo.com/video/83651159?title=0&byline=0&portrait=0"
                                frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //about section -->

    <!-- stats -->
    <!--<section class="w3_stats pb-5" id="stats">
        <div class="container pb-md-5 pb-4 pt-4">
            <div class="w3-stats">
                <div class="row text-center">
                    <div class="col-lg-3 col-sm-6">
                        <div class="counter">
                            <div class="timer count-title count-number" data-to="6300" data-speed="1500"></div>
                            <p class="count-text">Learners & counting</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mt-sm-0 mt-4">
                        <div class="counter">
                            <div class="timer count-title count-number" data-to="638" data-speed="1500"></div>
                            <p class="count-text">Total courses</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mt-lg-0 mt-4">
                        <div class="counter">
                            <div class="timer count-title count-number" data-to="7600" data-speed="1500"></div>
                            <p class="count-text">Successful students</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mt-lg-0 mt-4">
                        <div class="counter border-right-0">
                            <div class="timer count-title count-number" data-to="36" data-speed="1500"></div>
                            <p class="count-text">Languages</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>-->
    <!-- //stats -->

    <!-- about-bootom grids -->
    <section class="w3l-bottom-about py-5">
        <div class="container py-md-5 py-4">
            <div class="grids-area-hny main-cont-wthree-fea row">
                <div class="col-lg-4 col-md-6 grids-feature">
                    <div class="area-box">
                        <span class="fa fa-smile-o" aria-hidden="true"></span>
                        <h4><a href="#feature" class="title-head">Group Seminars</a></h4>
                        <p class="mb-3"></p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 grids-feature mt-md-0 mt-4">
                    <div class="area-box">
                        <span class="fa fa-graduation-cap icon-style-2" aria-hidden="true"></span>
                        <h4><a href="#feature" class="title-head">Trending Courses</a></h4>
                        <p class="mb-3"></p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 grids-feature mt-lg-0 mt-4">
                    <div class="area-box">
                        <span class="fa fa-users icon-style-3" aria-hidden="true"></span>
                        <h4><a href="#feature" class="title-head">Expert Teachers</a></h4>
                        <p class="mb-3"></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //bottom-grids-->

    <!-- team section -->

    <!-- //team setion -->

    <!-- about section -->
    <section class="w3l-about-3 pb-5 pt-2">
        <div class="container py-md-5 py-4 mb-5">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-6 pr-lg-5">
                    <h3 class="title-big">Join Our Mission to Democratize Education</h3>
                    <p class="mt-3">The Sant Gajanan Maharaj Group Of Education is one of the leading Education hub at Gadhinglaj comes under Shivaji University, Kolhapur.</p>
                    <ul class="list-about-2 mt-sm-4 mt-3">
                        <li class="py-1"><i class="fa fa-check-square-o mr-2" aria-hidden="true"></i>Approved by AICTE, New Delhi</li>
                        <li class="py-2"><i class="fa fa-check-square-o mr-2" aria-hidden="true"></i>Affiliated to Shivaji University , Kolhapur</li>
                        <li class="py-1"><i class="fa fa-check-square-o mr-2" aria-hidden="true"></i>Incubator in Development of Software's and Design & Development of Products</li>
                    </ul>
                </div>
                <div class="col-lg-6 about-2-secs-right mt-lg-0 mt-5">
                    <img src="assets/images/clgimage.jpg" alt="" class="img-fluid img-responsive"  width="1500" />
                </div>
            </div>
        </div>
    </section>
    <!-- //about section -->

    <!-- footer -->
    <?php include 'user_footer.php'; ?>