
<?php include 'user_header.php'; 

if(isset($_POST['btn']))
{

$_SESSION['dnames']=$_POST['dname'];
 // header('location:elearn.php');
echo "<script>
    window.location = 'elearn.php';
</script>";

}

?>
    <!--//header-->

    <!-- inner banner -->
    <div class="inner-banner">
        <div class="w3l-breadcrumb">
            <div class="container">
                <h4 class="inner-text-title font-weight-bold text-white mb-sm-3 mb-2">Departments</h4>
                <ul class="breadcrumbs-custom-path">
                    <li><a href="index.php">Home</a></li>
                    <li class="active"><span class="fa fa-chevron-right mx-2" aria-hidden="true"></span>Departments
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- //inner banner -->

    <!-- courses section -->
    <div class="w3l-grids-block-5 w3l-grids-block-6 py-5">
        <div class="container py-md-5 py-4">
            <div class="title-heading-w3 text-center mx-auto mb-5 pb-sm-4">
                <h3 class="title-main">Our <span>Departments</span></h3>
            </div>
            <div class="row">
<?php 

$sql=mysqli_query($conn,"select * from department_tbl");
while($data=mysqli_fetch_assoc($sql))
{
                echo '<div class="col-lg-4 col-md-6">
                <form action="department.php" method="post">
                    <div class="blog-card-single">
                        <div class="grids5-info position-relative">
                            <img src="../Admin/'.$data['file'].'" alt="" class="img-fluid" />
                        </div>
                        <div class="content-main-top">
                            <div class="content-top mb-4 mt-3">
                                <ul class="list-unstyled d-flex align-items-center justify-content-between">
                                    <li><i class="fa fa-signal" aria-hidden="true"></i></li>
                                    <li></li>
                                </ul>
                            </div>
                            <input type="hidden" name="dname" value="'.$data['dname'].'">
                            <h4><a href="#blog">'.$data['dname'].'</a></h4>
                            <p>'.$data['descr'].'</p>
                            <button type="submit" class="btn btn-primary" name="btn" >View More</button>
                        </div>
                    </div>
                    </form>
                </div>';
            }
                ?>
                
                
                
                
                
            </div>
            <!-- pagination -->
            
            <!-- //pagination -->
        </div>
    </div>
    <!-- //courses section -->

    <!-- footer -->
    <?php include 'user_footer.php'; ?>